clc;    % Clear the command window.
clear all;
close all; 
% train
txt = {'red-bottle-cap','green-sharpner','blue-comb', 'purple-toothbrush'}; 
for i =1:4 
     str='.\base image\';
     n = int2str(i);
     str = strcat(str,n,'.jpg');
     img=imread(str);
     I=img;
     img=rgb2gray(img);
     level=graythresh(img);
     img=im2bw(img,level-0.065);
     img=bwareaopen(img,700);
     info1 = regionprops(img,'MinorAxisLength','Centroid','MajorAxisLength','BoundingBox') ;
     MajorAxis=cat(1,info1.MajorAxisLength);
     MinorAxis=cat(1,info1.MinorAxisLength);
     d=MinorAxis/MajorAxis;
     cc=[0,0,0,0];
     BB = info1.BoundingBox;
     d=MinorAxis/MajorAxis;
     z=imcrop(img,[BB(1),BB(2),BB(3),BB(4)]);
     L = logical(z);
     c=imcrop(I,[BB(1),BB(2),BB(3),BB(4)]);
     c1=c(:,:,1);
     c2=c(:,:,2);
     c3=c(:,:,3);
     cc(1)=d;
     cc(2)= mean(c1(L));
     cc(3)=mean(c2(L));
     cc(4)=mean(c3(L));
     ac(i,1:4)=cc;
     disp(cc);
end

%test
target=ac;
[FileName,PathName]=uigetfile ({'*.gif;*.png;*.jpg', 'Supported Picture Formats'});
str=strcat(PathName,FileName);
%img=imread('.\test image\T_9.jpg'); 
img=imread(str);
imshow(img);
I=img;
img=rgb2gray(img);
level=graythresh(img);
img=im2bw(img,level-0.065);
img=bwareaopen(img,700);
info1 = regionprops(img,'MinorAxisLength','Centroid','MajorAxisLength','BoundingBox') ;
MajorAxis=cat(1,info1.MajorAxisLength);
MinorAxis=cat(1,info1.MinorAxisLength);
BB = info1.BoundingBox;
center=vertcat(info1.Centroid);
b=MinorAxis./MajorAxis;
k=zeros([1,4]); 
for i=1:length(b)
    cc=[0,0,0,0];
    BB = info1(i).BoundingBox;
    z=imcrop(img,[BB(1),BB(2),BB(3),BB(4)]);
    L = logical(z);
    c=imcrop(I,[BB(1),BB(2),BB(3),BB(4)]);
    c1=c(:,:,1);
    c2=c(:,:,2);
    c3=c(:,:,3);
    cc(1)=d;
    cc(2)= mean(c1(L));
    cc(3)=mean(c2(L));
    cc(4)=mean(c3(L));
    ac(i,1:4)=cc;
    t=target-ac;
    mse=sqrt(sum(t.^2,2));
    for j=1:4 
        t=target(j,:)-cc;
        mse(j)=sqrt(sum(t.^2));         
    end  
    [argvalue, argmin] = min(mse);
    position =  [uint16(center(i,1))-80  uint16(center(i,2))];
    I= insertText(I,position,txt{argmin},'FontSize',45,'BoxColor','green','TextColor','white');
    k(argmin)=1+k(argmin);
    disp(argmin)
end 
%write descreption to text file
m=sum(k);
m=[ ' ',stringnumber(m),' ' ];
str='this image consists of background black and  ';
str = strcat(str,' ',m ,' ',' objects that :\n');
fileID = fopen('discription.txt', 'wt'); 
fprintf(fileID,str);
for i=1:length(k)
    if k(i)~=0
        n=stringnumber(k(i));
        str = strcat(str,{' '},'( ',n,' )',{''},txt{i}); 
        fprintf(fileID,'%s %s',n,txt{i});
        fprintf(fileID,'\n');
    end
end
fclose(fileID);
figure;
imshow(I);
disp(str); 

