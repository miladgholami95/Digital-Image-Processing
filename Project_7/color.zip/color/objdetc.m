clc;    
clear all;
close all; 

% train
txt = {'red-bottle-cap','green-sharpner','blue-comb', 'purple-toothbrush'}; % Define the labels for the four classes of objects that the code will recognize.

for i =1:4 % For each class of object...
     str='.\base image\'; % Define the base directory where the images are stored.
     n = int2str(i); % Convert the loop index to a string.
     str = strcat(str,n,'.jpg'); % Append the loop index and the file extension to the base directory to form the full path to the image.
     img=imread(str); % Read the image file into an array.
     I=img; % Make a copy of the original image array.
     img=rgb2gray(img); % Convert the image to grayscale. This is done to simplify the image information for further processing.
     level=graythresh(img); % Compute a global threshold using Otsu's method.
     img=im2bw(img,level-0.065); % Convert the grayscale image to binary using the computed threshold.
     img=bwareaopen(img,700); % Remove all connected components (objects) that have fewer than 700 pixels from the binary image.
     info1 = regionprops(img,'MinorAxisLength','Centroid','MajorAxisLength','BoundingBox') ; % Measure properties of image regions such as the lengths of the minor and major axes of an ellipse equivalent to each object, the centroid, and the bounding box.
     MajorAxis=cat(1,info1.MajorAxisLength); % Concatenate the lengths of the major axes of all objects into a single array.
     MinorAxis=cat(1,info1.MinorAxisLength); % Concatenate the lengths of the minor axes of all objects into a single array.
     d=MinorAxis/MajorAxis; % Compute the ratio of the minor axis length to the major axis length for each object.
     cc=[0,0,0,0]; % Initialize an array to hold the features of each object.
     BB = info1.BoundingBox; % Get the bounding box of each object.
     d=MinorAxis/MajorAxis; % Compute the ratio of the minor axis length to the major axis length for each object.
     z=imcrop(img,[BB(1),BB(2),BB(3),BB(4)]); % Crop the binary image to the bounding box of each object.
     L = logical(z); % Convert the cropped image to logical.
     c=imcrop(I,[BB(1),BB(2),BB(3),BB(4)]); % Crop the original image to the bounding box of each object.
     c1=c(:,:,1); % Get the red channel of the cropped image.
     c2=c(:,:,2); % Get the green channel of the cropped image.
     c3=c(:,:,3); % Get the blue channel of the cropped image.
     cc(1)=d; % Store the ratio of the minor axis length to the major axis length as the first feature.
     cc(2)= mean(c1(L)); % Compute the mean of the red channel of the pixels within the object and store it as the second feature.
     cc(3)=mean(c2(L)); % Compute the mean of the green channel of the pixels within the object and store it as the third feature.
     cc(4)=mean(c3(L)); % Compute the mean of the blue channel of the pixels within the object and store it as the fourth feature.
     ac(i,1:4)=cc; % Store the features of each object in a row of the feature matrix.
     disp(cc); % Display the features of each object.
end

%test
target=ac; % Set the feature matrix as the target for comparison.
[FileName,PathName]=uigetfile ({'*.gif;*.png;*.jpg', 'Supported Picture Formats'}); % Open a file dialog for the user to select an image file.
str=strcat(PathName,FileName); % Concatenate the path and the file name to form the full path to the image file.
img=imread(str); % Read the image file into an array.
imshow(img); % Display the image.
I=img; % Make a copy of the original image array.
img=rgb2gray(img); % Convert the image to grayscale.
level=graythresh(img); % Compute a global threshold using Otsu's method.
img=im2bw(img,level-0.065); % Convert the grayscale image to binary using the computed threshold.
img=bwareaopen(img,700); % Remove all connected components (objects) that have fewer than 700 pixels from the binary image.
info1 = regionprops(img,'MinorAxisLength','Centroid','MajorAxisLength','BoundingBox') ; % Measure properties of image regions.
MajorAxis=cat(1,info1.MajorAxisLength); % Concatenate the lengths of the major axes of all objects into a single array.
MinorAxis=cat(1,info1.MinorAxisLength); % Concatenate the lengths of the minor axes of all objects into a single array.
BB = info1.BoundingBox; % Get the bounding box of each object.
center=vertcat(info1.Centroid); % Concatenate the centroids of all objects into a single array.
b=MinorAxis./MajorAxis; % Compute the ratio of the minor axis length to the major axis length for each object.
k=zeros([1,4]); % Initialize an array to hold the counts of each class of object.

for i=1:length(b) % For each object...
    cc=[0,0,0,0]; % Initialize an array to hold the features of each object.
    BB = info1(i).BoundingBox; % Get the bounding box of each object.
    z=imcrop(img,[BB(1),BB(2),BB(3),BB(4)]); % Crop the binary image to the bounding box of each object.
    L = logical(z); % Convert the cropped image to logical.
    c=imcrop(I,[BB(1),BB(2),BB(3),BB(4)]); % Crop the original image to the bounding box of each object.
    c1=c(:,:,1); % Get the red channel of the cropped image.
    c2=c(:,:,2); % Get the green channel of the cropped image.
    c3=c(:,:,3); % Get the blue channel of the cropped image.
    cc(1)=d; % Store the ratio of the minor axis length to the major axis length as the first feature.
    cc(2)= mean(c1(L)); % Compute the mean of the red channel of the pixels within the object and store it as the second feature.
    cc(3)=mean(c2(L)); % Compute the mean of the green channel of the pixels within the object and store it as the third feature.
    cc(4)=mean(c3(L)); % Compute the mean of the blue channel of the pixels within the object and store it as the fourth feature.
    ac(i,1:4)=cc; % Store the features of each object in a row of the feature matrix.
    t=target-ac; % Compute the difference between the target and the feature matrix.
    mse=sqrt(sum(t.^2,2)); % Compute the mean squared error between the target and the feature matrix.
    for j=1:4 % For each class of object...
        t=target(j,:)-cc; % Compute the difference between the target and the features of the current object.
        mse(j)=sqrt(sum(t.^2)); % Compute the mean squared error between the target and the features of the current object.
    end  
    [argvalue, argmin] = min(mse); % Find the minimum mean squared error and its index.
    position =  [uint16(center(i,1))-80  uint16(center(i,2))]; % Compute the position for the text annotation.
    I= insertText(I,position,txt{argmin},'FontSize',45,'BoxColor','green','TextColor','white'); % Insert the label of the class with the minimum mean squared error at the computed position in the image.
    k(argmin)=1+k(argmin); % Increment the count of the class with the minimum mean squared error.
    disp(argmin) % Display the index of the class with the minimum mean squared error.
end 

%write descreption to text file
m=sum(k); % Compute the total number of objects.
m=[ ' ',stringnumber(m),' ' ]; % Convert the total number of objects to a string.
str='this image consists of background black and  '; % Initialize the description string.
str = strcat(str,' ',m ,' ',' objects that :\n'); % Append the total number of objects to the description string.
fileID = fopen('discription.txt', 'wt'); % Open a text file for writing.
fprintf(fileID,str); % Write the description string to the text file.
for i=1:length(k) % For each class of object...
    if k(i)~=0 % If the count of the class is not zero...
        n=stringnumber(k(i)); % Convert the count to a string.
        str = strcat(str,{' '},'( ',n,' )',{''},txt{i}); % Append the count and the label of the class to the description string.
        fprintf(fileID,'%s %s',n,txt{i});  % Write the count and the class name to the text file.
        fprintf(fileID,'\n');  % Write a newline to the text file.
    end
end
fclose(fileID);  % Close the text file.
figure;  % Create a new figure window.
imshow(I);  % Display the image with the class names.
disp(str);  % Display the description string.

