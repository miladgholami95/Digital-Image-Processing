function [s] =stringnumber(n)
  switch n
      case 1
          s=' one';
      case 2
          s='two';
      case 3
          s='three';
      case 4
          s='four'; 
     
         
    otherwise
        s='many';
  end
end

